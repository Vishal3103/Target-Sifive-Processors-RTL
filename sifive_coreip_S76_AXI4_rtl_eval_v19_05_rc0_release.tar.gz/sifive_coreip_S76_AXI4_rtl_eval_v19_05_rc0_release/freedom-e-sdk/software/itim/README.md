# example-itim
Demonstrates how to designate a function to be linked into the ITIM
(Instruction Tightly-Integrated Memory).
