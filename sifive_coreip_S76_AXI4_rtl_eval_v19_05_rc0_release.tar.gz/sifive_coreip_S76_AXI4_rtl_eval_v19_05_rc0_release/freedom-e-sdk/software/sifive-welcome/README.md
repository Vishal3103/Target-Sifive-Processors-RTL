# sifive-welcome
A simple welcome example which prints SiFive banner and uses board LEDs
