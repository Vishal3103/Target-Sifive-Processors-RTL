# benchmark-dhrystone
"DHRYSTONE" Benchmark Program by  Reinhold P. Weicker
