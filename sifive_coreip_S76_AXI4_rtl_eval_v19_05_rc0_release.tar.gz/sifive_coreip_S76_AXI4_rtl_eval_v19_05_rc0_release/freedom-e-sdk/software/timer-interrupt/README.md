# example-timer-interrupt
A simple "Timer Interrupt" example using metal-interrupts APIs for registration and stroking machine cycle.
